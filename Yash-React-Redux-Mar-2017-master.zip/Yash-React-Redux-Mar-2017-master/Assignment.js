var products = [
	{id : 6, name : 'Pen', cost : 60, units : 10, category : "stationary"},
	{id : 3, name : 'Rice', cost : 20, units : 70, category : "grocery"},
	{id : 9, name : 'Dal', cost : 80, units : 40, category : "grocery"},
	{id : 8, name : 'Pencil', cost : 50, units : 90, category : "stationary"},
	{id : 2, name : 'Vegetables', cost : 90, units : 20, category : "vegetables"},
]

//Shopping Cart

Id + Name, Cost , Category 
Units , Discount
Calculate

