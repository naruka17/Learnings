var myApp = angular.module('myApp.services', []);

myApp.factory('', function() {});