export interface IBug{
	name : string,
	isClosed : boolean,
	createdAt : Date
}