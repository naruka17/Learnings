export interface IBug{
	id : number,
	name : string,
	isClosed : boolean,
	createdAt : Date
}